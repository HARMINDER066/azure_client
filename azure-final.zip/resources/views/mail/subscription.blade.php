{!! $template_message !!}.
