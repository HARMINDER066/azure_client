<?php
return [
    'origin' => config('constants.google.RECAPTCHAV3_ORIGIN'),
    'sitekey' => config('constants.google.RECAPTCHAV3_SITEKEY'),
    'secret' => config('constants.google.RECAPTCHAV3_SECRET')
];
