<?php echo $template_message; ?>.
<?php /**PATH /var/www/api.chatsilo.com/resources/views/mail/subscription.blade.php ENDPATH**/ ?>