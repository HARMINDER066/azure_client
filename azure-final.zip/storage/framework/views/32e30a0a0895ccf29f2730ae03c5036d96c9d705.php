<!DOCTYPE html>
<html>
<head>
  
  <?php if ($__env->exists('staff.partial.head')) echo $__env->make('staff.partial.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <style>
      .table-responsive {
    display: inline-table;
    /* width: 100%; */
    /* overflow-x: auto; */
}
  </style>
</head>

<body>
      <div class="theme-loader">
         <div class="ball-scale">
            <div class='contain'>
               <div class="ring">
                  <div class="frame"></div>
               </div>
               <div class="ring">
                  <div class="frame"></div>
               </div>
               <div class="ring">
                  <div class="frame"></div>
               </div>
               <div class="ring">
                  <div class="frame"></div>
               </div>
               <div class="ring">
                  <div class="frame"></div>
               </div>
               <div class="ring">
                  <div class="frame"></div>
               </div>
               <div class="ring">
                  <div class="frame"></div>
               </div>
               <div class="ring">
                  <div class="frame"></div>
               </div>
               <div class="ring">
                  <div class="frame"></div>
               </div>
               <div class="ring">
                  <div class="frame"></div>
               </div>
            </div>
         </div>
      </div>
      <div id="pcoded" class="pcoded">
         <div class="pcoded-overlay-box"></div>
         <div class="pcoded-container navbar-wrapper">
    <?php echo $__env->make('staff.partial.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="pcoded-main-container">
               <div class="pcoded-wrapper">
    <?php echo $__env->make('staff.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <!-- Content Wrapper. Contains page content -->
      <?php echo $__env->yieldContent('content'); ?>
</div>
</div>
  </div>
</div>
</div>
  <!-- /.content-wrapper -->

  <?php echo $__env->make('staff.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /home/kamilkozar/public_html/admin/resources/views/staff/app.blade.php ENDPATH**/ ?>