<title>ChatSilo</title>
      <!--[if lt IE 10]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="description" content="#">
      <meta name="keywords" content="Admin , Responsive, Landing, Bootstrap, App, Template, Mobile, iOS, Android, apple, creative app">
      <meta name="author" content="#">
    <link rel="icon" href="<?php echo e(asset('backend/files/assets/images/fav.png')); ?>" type="image/x-icon">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/assets/icon/feather/css/feather.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/bower_components/pnotify/dist/pnotify.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/bower_components/pnotify/dist/pnotify.brighttheme.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/bower_components/pnotify/dist/pnotify.buttons.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/bower_components/pnotify/dist/pnotify.history.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/bower_components/pnotify/dist/pnotify.mobile.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/assets/pages/pnotify/notify.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/assets/icon/icofont/css/icofont.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/assets/css/style.css')); ?>">
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/files/assets/css/jquery.mCustomScrollbar.css')); ?>">
      <?php echo $__env->yieldPushContent('custom-css'); ?>
<?php /**PATH /var/www/api.chatsilo.com/resources/views/admin/partial/head.blade.php ENDPATH**/ ?>