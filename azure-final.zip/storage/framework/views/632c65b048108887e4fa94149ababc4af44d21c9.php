<?php echo $template_message; ?>.
<?php /**PATH /var/www/admin.chatsilo.com/resources/views/mail/subscription.blade.php ENDPATH**/ ?>