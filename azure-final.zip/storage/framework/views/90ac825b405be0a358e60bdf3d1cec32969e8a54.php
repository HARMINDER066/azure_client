

<?php $__env->startSection('content'); ?>
<div class="pcoded-content"> 
<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">
<div class="page-body">   
<div class="page-header">
  <div class="row align-items-end">
    <div class="col-lg-8">
      <div class="page-header-title">
        <div class="d-inline">
          <h4>User Plan Upgrade/DownGrade</h4>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>           
<div class="page-body">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-block">
          <h4 class="sub-title">User Details</h4>
        <div class="col-lg-12 col-xl-12">
             <div class="card">
        <div class="card-block">
              <form method="post" class="col-md-8" action="<?php echo e(route('user.updateSubscriptionStore', ['id' => $userdetail->id])); ?>">
                <?php echo csrf_field(); ?>
    <div class="form-group row">
        <span class="label-text col-md-3 col-form-label">Name</span>

        <div class="col-md-9">
        <?php echo e($userdetail->name); ?>

    </div>
    </div>
      <div class="form-group row">
        <span class="label-text col-md-3 col-form-label">Email</span>

        <div class="col-md-9">
      <?php echo e($userdetail->email); ?> 
    </div>
    </div>
           <div class="form-group row">
        <span class="label-text col-md-3 col-form-label">Facebook Id</span>

        <div class="col-md-9">
          <?php if(count($userdetail->account)): ?>
      <?php echo e($userdetail->account[0]->fb_account_id); ?> 
      <?php endif; ?>
     </div>
    </div>
  
  <div class="form-group row">
        <span class="label-text col-md-3 col-form-label">Current Plan</span>

        <div class="col-md-9">
      <?php echo e($userdetail->plan->name); ?> 
    </div>
    </div>
    <div class="form-group row">
        <span class="label-text col-md-3 col-form-label">Renew Date</span>

        <div class="col-md-9">
     <?php echo e($userdetail->expired_on); ?>

    </div>
    </div>
                    
  <div class="form-group row">
        <span class="label-text col-md-3 col-form-label">Select Plan*</span>
   <div class="col-md-9">
      <select class="form-control" name="plan_id">
         <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($plan->id); ?>" <?php echo e(($plan->id == $userdetail->plan_id) ? "selected" : ""); ?>>
          <?php echo e($plan->name); ?> - <?php echo e($plan->plan_type); ?> ($<?php echo e($plan->amount); ?>)
          </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </select>
        </div>
    </div>                  
    <div class="row mt-3">
        <div class="col-md-9 offset-md-3">
            <input type="submit" value="Update" class="btn btn-rounded btn-success">
        </div>
    </div>
</form>

                </div>
            </div>
          </div>
        </div>
      </div>
   </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
 <?php $__env->stopSection(); ?>
           
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/api.chatsilo.com/resources/views/admin/user/userplan.blade.php ENDPATH**/ ?>