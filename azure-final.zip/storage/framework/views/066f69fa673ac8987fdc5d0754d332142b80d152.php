Hi <?php echo e($name); ?><br/><br/>
TYour Subscription plan has cancelled. Please contact administrator to reactivate.


Thank you<br/>Group Leads Team.<?php /**PATH C:\xampp\htdocs\harminder\example-app\resources\views/mail/signup.blade.php ENDPATH**/ ?>